
function main(document){
    xmlList.loadSurveyByType(1,document.body)
    // xmlRequest.readXMLFromDB(46,document.body).then(function(e){
    //     console.log(e)
    // })
    // xmlRequest.goAsyn(["XMLfile/template.xml","XMLfile/template1.xml","XMLfile/template2.xml"],document.body).then(function(e){
    //     console.log(e)
    // })
}