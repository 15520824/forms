
function main(document){
    xmlListCreate.loadSurveyByType(1,document.body)
    // xmlRequestCreate.readXMLFromDB(47,document.body).then(function(e){
    //     console.log(e)
    // })
    // xmlRequestCreate.goAsyn(["XMLfile/template.xml","XMLfile/template1.xml","XMLfile/template2.xml"],document.body).then(function(e){
    //     console.log(e)
    // })
}