<?php
    $currentDir = getcwd();
    $uploadDirectory = dirname("/../../img/upload");
    echo dirname(dirname(__FILE__));
?>