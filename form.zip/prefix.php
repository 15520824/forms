<?php $prefix = "lab_form_";
    $prefixhome = "lab_home_";
    $hrdb = "hr_db";
    $hrprefix = "hr_";
    $dbhome = "home_lab";
?>
