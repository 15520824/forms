<?php 
include_once "../jsdb.php";
include_once "../jsencoding.php";
include_once "../prefix.php";
include_once "../connection.php";

echo md5("1"."safe.Login.via.normal.HTTP"."000000")
?>