<?php
	include_once	"prefix.php";
	include_once	"connection.php";

    session_start();
?>
